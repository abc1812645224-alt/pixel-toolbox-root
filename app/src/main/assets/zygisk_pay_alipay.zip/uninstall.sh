#!/sbin/sh
MODDIR=${0%/*}
rm -f "/data/local/tmp/libzygisk-module-xfingerprint-pay-alipay.dex" || true
